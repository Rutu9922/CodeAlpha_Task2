package com.hotel;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.hotel.models.Room;
import com.hotel.services.HotelService;
import com.hotel.services.PaymentService;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		HotelService hotelService = new HotelService();
		PaymentService paymentService = new PaymentService();
		
		//RoomSeeder.insertSampleRooms();
		
		while(true) {
			System.out.println("\n=== Hotel Reservation System");
			System.out.println("1. View Available Rooms");
			System.out.println("2. Book a Room");
			System.out.println("3. Cancel Booking");
			System.out.println("4. View Booking");
			System.out.println("5. Exit");
			System.out.println("Enter choice: ");
			int choice = sc.nextInt();
			try {
				switch(choice){
				case 1:
					List<Room> rooms = hotelService.getAvailableRooms();
					for(Room r : rooms) {
					System.out.println("Room ID: " + r.getRoomId() + ", Category: " + r.getCategory() + ",Price per Night: ₹" + r.getPricePerNight());
					
				}
				break;
				
				case 2:
					sc.nextLine();
					System.out.print("Enter Name: ");
					String name = sc.nextLine();
					System.out.print("Enter Contact: ");
                    String contact = sc.nextLine();
                    int customerId = hotelService.addCustomer(name, contact);
                    
                    
                    System.out.print("Enter Room ID to Book: ");
                    int roomId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Check_in Date (yyyy-mm-dd): ");
                    Date checkIn = Date.valueOf(sc.nextLine());
                    System.out.print("Enter Check_out Date (yyyy-mm-dd): ");
                    Date checkOut = Date.valueOf(sc.nextLine());
                    
                    double price = 0;
                    for (Room r : hotelService.getAvailableRooms()) {
                        if (r.getRoomId() == roomId) {
                            price = r.getPricePerNight();
                            break;
                        }
                  }
                    double totalAmount = paymentService.calculateAmount(price, checkIn, checkOut);
                    hotelService.bookRoom(customerId, roomId, checkIn, checkOut, totalAmount);
                    System.out.println("Booking successful! Total amount: " + totalAmount);
                    break;
                    
				case 3:
					System.out.println("Enter Booking ID to Cancel: ");
					int bookingId = sc.nextInt();
					boolean isCancelled = hotelService.cancelBooking(bookingId);
					System.out.println(isCancelled ? "Cancelled successfully!" : "Cancellation failed!");
					break;
					
				case 4:
					hotelService.viewBookings();
					break;
                
				case 5:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid option.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
	}
}

