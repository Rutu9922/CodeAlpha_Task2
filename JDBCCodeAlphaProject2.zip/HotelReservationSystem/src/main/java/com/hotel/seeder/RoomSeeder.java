package com.hotel.seeder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.hotel.db.DatabaseConnection;

public class RoomSeeder {
	
	public static void insertSampleRooms()
    {
    	Connection con = null;
    	PreparedStatement pst = null;
    	int check = 0;
    	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DatabaseConnection.getConnection();
		//System.out.println("driver loaded sucessfully in the program");
		String sql = "insert into rooms(room_id,category,price_per_night,is_available)values(?,?,?,?)";
		pst = con.prepareStatement(sql);
		pst.setInt(1, 105);
		pst.setString(2,"Deluxe");
		pst.setDouble(3, 8000);
		pst.setBoolean(4,true);
		check = pst.executeUpdate();
		System.out.println("Rows inserted successfully: "+check);
	} catch (ClassNotFoundException | SQLException e) {
		e.printStackTrace();
	}
    finally 
    {
    	try {
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
   }
  }
}

