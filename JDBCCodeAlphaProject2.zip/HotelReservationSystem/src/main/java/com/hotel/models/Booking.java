package com.hotel.models;

import java.util.Date;

public class Booking {
	private int bookingId;
	private int customerId;
	private int roomId;
	private Date checkInDate;
	private Date checkOutDate;
	private double totalAmount;
	public Booking(int bookingId, int customerId, int roomId, Date checkInDate, Date checkOutDate, double totalAmount) {
		super();
		this.bookingId = bookingId;
		this.customerId = customerId;
		this.roomId = roomId;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.totalAmount = totalAmount;
	}
	public int getBookingid() {
		return bookingId;
	}
	public void setBookingid(int bookingid) {
		this.bookingId = bookingid;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public Date getCheckIn() {
		return checkInDate;
	}
	public void setCheckIn(Date checkIn) {
		this.checkInDate = checkIn;
	}
	public Date getCheckOut() {
		return checkOutDate;
	}
	public void setCheckOut(Date checkOut) {
		this.checkOutDate = checkOut;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

}
