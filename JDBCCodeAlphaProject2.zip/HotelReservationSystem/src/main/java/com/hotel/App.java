package com.hotel;

import com.hotel.seeder.RoomSeeder;

public class App 
{
   public static void main(String[] args) 
   {
	   RoomSeeder.insertSampleRooms();
   }
}

