package com.hotel.services;

import java.sql.Date;

public class PaymentService {
	public double calculateAmount(double pricePerNight, Date checkIn, Date checkOut) {
		long diff = checkOut.getTime() - checkIn.getTime();
		int days = (int)(diff/(1000 * 60 * 60 * 24));
		return pricePerNight * (days == 0 ? 1 : days);
		
	}
		
	}


