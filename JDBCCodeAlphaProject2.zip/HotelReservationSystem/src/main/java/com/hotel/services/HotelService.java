package com.hotel.services;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hotel.db.DatabaseConnection;
import com.hotel.models.Customer;
import com.hotel.models.Room;

public class HotelService {
	public List<Room> getAvailableRooms() throws SQLException{
		List<Room> roomList = new ArrayList<>();
		
	Connection con = DatabaseConnection.getConnection();
	String sql = "select * from rooms where is_available = true";
	PreparedStatement pst = con.prepareStatement(sql);
	ResultSet rs = pst.executeQuery();
		
		while (rs.next()) {
            Room room = new Room(
                    rs.getInt("room_id"),
                    rs.getString("category"),
                    rs.getDouble("price_per_night"),
                    rs.getBoolean("is_available")
            );
            roomList.add(room);
        }
			return roomList;
		}
	
	//Book a room
	public int addCustomer(String name, String contact) throws SQLException{
		Connection con = DatabaseConnection.getConnection();{
		String sql = "insert into customers(name,contact)values(?,?)";
		PreparedStatement pst = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		pst.setString(1, name);
		pst.setString(2, contact);		
		pst.executeUpdate();
		ResultSet rs = pst.getGeneratedKeys();
			if(rs.next()) {
				return rs.getInt(1);
		}
			return -1;
		}
	}
				
	public void bookRoom(int customerId, int roomId, Date checkIn, Date checkOut, double totalAmount) throws SQLException{
		String sql = "insert into bookings(customer_id, room_id, check_in_date, check_out_date, total_amount)values(?,?,?,?,?)";
		Connection con = DatabaseConnection.getConnection();
		PreparedStatement pst1 = con.prepareStatement(sql);
	    pst1.setInt(1, customerId);
	    pst1.setInt(2, roomId);
	    pst1.setDate(3, checkIn);
	    pst1.setDate(4, checkOut);
	    pst1.setDouble(5, totalAmount);
	    pst1.executeUpdate();
	             
	    String sql2 = "update rooms set is_available = false where room_id = ?";
	    PreparedStatement pst2 = con.prepareStatement(sql2);
	    pst2.setInt(1, roomId);
	    pst2.executeUpdate();
	    }
	
	
	//Cancel a booking by booking_id
	public boolean cancelBooking(int bookingId) {
		try {
			Connection con = DatabaseConnection.getConnection();
			
			String sql = "select room_id from bookings where booking_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, bookingId);
			ResultSet rs = pst.executeQuery();
			
			if(!rs.next()) {
				System.out.println("Booking Not Found.");
				return false;
			}
			
			int roomId = rs.getInt("room_id");
			
			//Delete Booking
			String sql1 = "delete from bookings where booking_id = ?";
			PreparedStatement pst1 = con.prepareStatement(sql1);
			pst1.setInt(1, bookingId);
			pst1.executeUpdate();
			
			//Make room available
			String sql2 = "update rooms set is_available = true where room_id = ?";
			PreparedStatement pst2 = con.prepareStatement(sql2);
			pst2.setInt(1, roomId);
			pst2.executeUpdate();
			
			System.out.println("Booking cancelled successfully.");
			return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	//View all bookings
	public boolean viewBookings() {
		try {
			Connection con = DatabaseConnection.getConnection();
			String sql = "Select b.booking_id, c.name, c.contact, r.category, b.check_in_date, b.check_out_date, b.total_amount " + "from bookings b join customers c on b.customer_id = c.customer_id " + "join rooms r on b.room_id = r.room_id";
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			System.out.println("\n--- All Bookings ---");
			while(rs.next()) {
				System.out.println("Booking ID: " + rs.getInt("booking_id"));
				System.out.println("Customer Name: " + rs.getString("name"));
				System.out.println("Contact: " + rs.getString("contact"));
				System.out.println("Room Type: " + rs.getString("category"));
				System.out.println("Check-in: " + rs.getDate("check_in_date"));
				System.out.println("Check-out: " + rs.getDate("check_out_date"));
				System.out.println("Total Paid: ₹ " + rs.getDouble("total_amount"));
				System.out.println("-------------------------------");
				
			}
			
		}catch(SQLException e) {
			e.printStackTrace();		}
		
		return false;
		
	}
	}
